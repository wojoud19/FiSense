import requests
import csv
import os

API_KEY = "sk_a595f7a0511021bcefdace43fa55a710e40f6a6c0afe4602"
VOICE_ID = "8KMBeKnOSHXjLqGuWsAE"

os.makedirs("elderly_dataset/audio", exist_ok=True)

prompts = [
    "افتحلي التطبيق",
    "كم في حسابي؟",
    "حوّل لخالد خمسين ريال",
    "ابغى أعرف كم صرفت هالأسبوع",
    "رجّعني ورا شوي",
    "اقرا لي الرصيد بصوت عالي",
    "أرسل لعلي مية، بسرعة لو سمحت",
    "ابي أحوّل للمحفظة حقتي",
    "خلني أشوف حساب بنتي",
    "يا تطبيق، ساعدني شوي أنا ما أشوف",
    "ابغى أراجع العمليات اللي قبل",
    "وين الفلوس اللي دخلت أمس؟",
    "ذكّرني أرسل مبلغ الشهر الجاي",
    "اقرا لي كم دفعت للكهربا",
    "افتح الإشعارات اللي فاتتني"
]


csv_path = "elderly_dataset/transcripts.csv"
with open(csv_path, mode='w', encoding='utf-8', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["filename", "text"])

    for i, text in enumerate(prompts):
        output_filename = f"elderly_voice_sample_{i+1}.mp3"
        audio_path = f"elderly_dataset/audio/{output_filename}"

        response = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}",
            headers={
                "Accept": "audio/mpeg",
                "Content-Type": "application/json",
                "xi-api-key": API_KEY
            },
            json={
                "text": ". " + text,  # ← النقطة تساعد على تصحيح الاتجاه أحيانًا
                "model_id": "eleven_multilingual_v2",  # ← هذا يدعم العربية
                "voice_settings": {
                    "stability": 0.85,
                    "similarity_boost": 0.8,
                    "style": 0.2,
                    "use_speaker_boost": True
                }
            }
        )

        if response.status_code == 200:
            with open(audio_path, "wb") as audio_file:
                audio_file.write(response.content)
            writer.writerow([output_filename, text])
            print(f"Saved: {output_filename}")
        else:
            print(f"Failed to generate audio for: {text}")
            print(f"Status Code: {response.status_code}, Message: {response.text}")
