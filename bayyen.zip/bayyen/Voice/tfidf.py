from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
import speech_recognition as sr

# =====================
# 1. عينات التدريب
# =====================
samples = [
    # transfer
    ("أبغى أحول لولدي", "transfer"),
    ("ودي أحول مبلغ", "transfer"),
    ("ابغاك تحول ل ولدي ١٠٠ ريال", "transfer"),
    ("أرسل فلوس لخالد", "transfer"),
    ("حول ٥٠٠ ريال لأخوي", "transfer"),
    ("ودي أنقل فلوس لأبوي", "transfer"),

    # add_beneficiary
    ("أبغى أضيف رقم خالد", "add_beneficiary"),
    ("كيف أضيف مستفيد جديد؟", "add_beneficiary"),
    ("سجل رقم حساب جديد", "add_beneficiary"),

    # check_balance
    ("كم باقي في حسابي؟", "check_balance"),
    ("أبغى أشوف حسابي", "check_balance"),
    ("كم في الرصيد؟", "check_balance"),

    # pay_bill
    ("أبغى أدفع فاتورة الكهرب", "pay_bill"),
    ("ودي أسدد فاتورة", "pay_bill"),

    # go_back
    ("رجعني للصفحة اللي قبل", "go_back"),
    ("أبغى أرجع للخلف", "go_back"),
]

# =====================
# 2. تجهيز البيانات والنموذج
# =====================
texts, intents = zip(*samples)
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)

model = LinearSVC()
model.fit(X, intents)

# =====================
# 3. دالة التعرف على الصوت
# =====================
def get_audio():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙️ تكلّم الآن...")
        audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio, language="ar-SA")
        print("📝 تم تحويل الصوت إلى نص:", text)
        return text
    except sr.UnknownValueError:
        print("❌ لم أفهم الصوت.")
        return ""
    except sr.RequestError as e:
        print(f"🚫 مشكلة في الاتصال: {e}")
        return ""

# =====================
# 4. استخدام الصوت لتحديد النية
# =====================
spoken_text = get_audio()

if spoken_text:
    test_vector = vectorizer.transform([spoken_text])
    predicted_intent = model.predict(test_vector)[0]
    print("🔎 النية المتوقعة:", predicted_intent)
else:
    print("🚫 لم يتم التصنيف بسبب فشل التعرف على الصوت.")
