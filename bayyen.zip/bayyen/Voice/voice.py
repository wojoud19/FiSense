import whisper
import arabic_reshaper
from bidi.algorithm import get_display

import warnings
warnings.filterwarnings("ignore", category=UserWarning)

model = whisper.load_model("small")

result = model.transcribe("elderly_dataset/audio/elderly_voice_sample_10.mp3", language="ar")

reshaped_text = arabic_reshaper.reshape(result["text"])
bidi_text = get_display(reshaped_text)

print(":Text", bidi_text)
